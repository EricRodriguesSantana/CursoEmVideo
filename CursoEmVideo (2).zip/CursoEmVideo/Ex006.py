A = int(input('Um número real: '))
print(f'O produto do seu número real é {A*2}. \nO triplo dele é {A*3}. \nA raiz quadrada dele é {A**(1/2):.2f}! ')
