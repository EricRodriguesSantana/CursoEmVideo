salário = float(input('Você recebeu um aumento de 15%! Qual é o seu salário líquido atual? R$'))
novo = salário + (salário * 15/100)
print(f'Com o acréscimo do aumento, o seu salário líquido atual é de R${novo:.2f}.')

