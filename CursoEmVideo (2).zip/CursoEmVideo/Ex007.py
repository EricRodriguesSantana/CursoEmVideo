N1 = float(input('Qual foi a nota da primeira prova de Joãozinho? ' ))
N2 = float(input('Qual foi a nota da segunda prova de Joãozinho? ' ))
M = (N1+N2)/2
print(f'A média de Joãozinho é {M:.1f}! ')
