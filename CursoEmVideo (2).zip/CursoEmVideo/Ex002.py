nome = input('Digite seu nome: ')
print('Seja bem vindo, {}!'.format(nome))

print(f'Seja bem vindo, {nome}!')