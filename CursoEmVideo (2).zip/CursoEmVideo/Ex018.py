import math
angulo = int(input('Digite um ângulo: '))
radian = math.radians(angulo)
seno = math.sin(radian)
cos = math.cos(radian)
tan = math.tan(radian)
print(f'O cosseno é {cos:.2f}, o seno é {seno:.2f} e a tangente é {tan:.2f} do ângulo {angulo:.2f}. ')


