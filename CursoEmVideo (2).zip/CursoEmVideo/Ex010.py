R = float(input('Quanto de dinheiro você tem? Irei convertê-lo em dólares: R$'))
D = (R/3.27)
print(f'Você pode comprar {D:.2f} dólares! ')