A = float(input('Qual a altura em metros da parede a ser pintada? '))
L = float(input('Qual é a largura em metros dela? '))
AL = A*L
T = AL/2
print(f'A área a ser pintada é de {AL} m² e será gasto {T} litros de tinta. ')
