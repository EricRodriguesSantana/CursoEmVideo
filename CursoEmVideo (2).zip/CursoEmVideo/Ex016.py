import math
num = float(input('Fale um número: '))
num1 = math.floor(num)
print(f'O número {num} tem a porção inteira {num1}.')

