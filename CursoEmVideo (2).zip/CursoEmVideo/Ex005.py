A = int(input('Diga-me um número: '))
print(f'O antecessor de {A} é {A-1} e o sucessor é {A+1}! ')