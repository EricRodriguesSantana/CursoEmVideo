P = float(input('Qual é o valor do produto? Você ganhará um desconto de 5%! R$'))
PF =  P*5/100
PFF = P-PF
print(f'O valor do seu desconto foi aplicado! Agora, o valor do produto foi alterado para R${PFF:.2f}! ')
