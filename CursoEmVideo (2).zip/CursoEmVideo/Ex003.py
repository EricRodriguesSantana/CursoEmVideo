n1 = int(input('Digite um número: '))
n2 = int(input('Digite outro número: '))
s = n1+n2
print(f'A soma dos números {n1} e {n2} é {s}')